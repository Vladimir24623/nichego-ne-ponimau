const gamesRouter = require("express").Router();
const { addGameController, deleteGame, sendAllGames } = require("../controllers/games");
const { getALLGames } = require("../middlewares/games")

games.Router.post("/games", getALLGames, addGameController);
games.Router.get("/games", getALLGames, sendAllGames);
games.Router.delete("/games/:id", getALLGames, deleteGame);


module.exports = gamesRouter;